package com.example.rabin.hw04;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Connection;

public class MainActivity extends AppCompatActivity {

    Button go;
    ImageView image, prev, next;
    String[] search, output;
    int temp = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Main Activity");
        image = (ImageView) findViewById(R.id.iv_main);
        prev = (ImageView) findViewById(R.id.iv_previous);
        next = (ImageView) findViewById(R.id.iv_next);
        prev.setEnabled(false);
        next.setEnabled(false);
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        Log.d("test", String.valueOf(networkInfo.getType()));
        if (networkInfo != null || networkInfo.isConnected() || networkInfo.getType() == ConnectivityManager.TYPE_WIFI || networkInfo.getType() == ConnectivityManager.TYPE_MOBILE) {
            Toast.makeText(this, "Internet Enabled", Toast.LENGTH_SHORT).show();
            new GetDataAsync().execute("http://dev.theappsdr.com/apis/photos/keywords.php");
            new GetImageAsync().execute("http://dev.theappsdr.com/apis/photos/index.php");
            RequestParams params = new RequestParams();
            params.addParameter("keyword", "winter");
            new GetDataUsingParamAsync(params).execute("http://dev.theappsdr.com/apis/photos/index.php");
        } else {
            Toast.makeText(this, "Please enable internet connection", Toast.LENGTH_SHORT).show();
            //new GetDataAsync().execute("http://dev.theappsdr.com/apis/photos/keywords.php");
        }
        //for (int i = 0; i <4; i++){
        //   new  GetImage1Async().execute(output[i]);
        //}
        go = (Button) findViewById(R.id.b_go);
        go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                search = new String[movieList.size()];
                for (int i = 0; i < movieList.size(); i++) {
                    search[i] = movieList.get(i).getSname();
                }

                builder.setTitle("Choose a keyword").setItems(search, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }

                });
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
    }
        /*ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        if (networkInfo == null || !networkInfo.isConnected() || networkInfo.getType() != ConnectivityManager.TYPE_WIFI || networkInfo.getType() != ConnectivityManager.TYPE_MOBILE) {
            Toast.makeText(MainActivity.this, "Please enable internet connection", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(MainActivity.this, "Internet Connection Enabled", Toast.LENGTH_SHORT).show();
            new GetDataAsync().execute("http://dev.theappsdr.com/apis/photos/keywords.php");
        }*/
       // if (temp == 0)
         //   prev.setVisibility(View.INVISIBLE);
        //else
          //  prev.setVisibility(View.VISIBLE);

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              //  if (temp == output.length)
                //    next.setVisibility(View.INVISIBLE);
               // else {
                   // next.setVisibility(View.VISIBLE);
                    if (temp < output.length) {
                        new GetImage1Async().execute(output[temp++]);
                 //   }
                }
            }
        });
        prev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (temp>0){
                    new GetImage1Async().execute(output[temp--]);
                }
            }
        });
    }


    /*private boolean isConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        if (networkInfo == null || !networkInfo.isConnected() || networkInfo.getType() != ConnectivityManager.TYPE_WIFI || networkInfo.getType() != ConnectivityManager.TYPE_MOBILE) {
            return false;
        } else {
            return true;
        }
    }*/


    private class GetDataAsync extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... params) {
            HttpURLConnection connection = null;
            BufferedReader reader = null;
            InputStream inputStream = null;
            StringBuilder stringBuilder = new StringBuilder();
            String result = null;
            try {
                URL url = new URL(params[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.connect();
                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    inputStream = connection.getInputStream();
                    reader = new BufferedReader(new InputStreamReader(inputStream));
                    String line = "";
                    while ((line = reader.readLine()) != null) {
                        stringBuilder.append(line);
                    }
                    result = stringBuilder.toString();
                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (connection != null)
                    connection.disconnect();
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
            return result;
        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null) {
                String[] output = result.split(";");
                /*for (int i=0; i<6;i++)
                Log.d("abisearchvalue1", String.valueOf(output[0]));
                Log.d("abisearchvalue2", String.valueOf(output[1]));
                Log.d("abisearchvalue3", String.valueOf(output[2]));
                Log.d("abisearchvalue4", String.valueOf(output[3]));
                Log.d("abisearchvalue5", String.valueOf(output[4]));
                Log.d("abisearchvalue6", String.valueOf(output[5])); */
            } else Log.d("abinull", null);
        }
    }

    private class GetImageAsync extends AsyncTask<String, Void, Bitmap> {
        @Override
        protected Bitmap doInBackground(String... params) {
            HttpURLConnection connection = null;
            Bitmap bitmap = null;
            URL url = null;
            try {
                url = new URL(params[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.setDoInput(true);
                connection.connect();
                /*for (int i = 0; i < 100; i++) {
                    for (int j = 1; j < 100000; j++) {
                    }
                    publishProgress(i);
                }*/

                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    bitmap = BitmapFactory.decodeStream(connection.getInputStream());
                }

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return bitmap;
        }


        @Override
        protected void onPostExecute(Bitmap bitmap) {
            image.setImageBitmap(bitmap);
        }
    }

    private class GetDataUsingParamAsync extends AsyncTask<String, Void, String> {
        RequestParams mparams;

        public GetDataUsingParamAsync(RequestParams params) {
            mparams = params;
        }

        @Override
        protected String doInBackground(String... params) {
            HttpURLConnection connection = null;
            BufferedReader reader = null;
            InputStream inputStream = null;
            StringBuilder stringBuilder = new StringBuilder();
            String result = null;
            try {
                URL url = new URL(mparams.getEncodedUrl(params[0]));
                connection = (HttpURLConnection) url.openConnection();
                connection.connect();
                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    inputStream = connection.getInputStream();
                    reader = new BufferedReader(new InputStreamReader(inputStream));
                    String line = "";
                    while ((line = reader.readLine()) != null) {
                        stringBuilder.append(line);
                    }
                    result = stringBuilder.toString();
                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (connection != null)
                    connection.disconnect();
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
            return result;
        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null) {
                prev.setEnabled(true);
                next.setEnabled(true);
                output = result.split(".jpg");
                //Log.d("out loop", String.valueOf(result.length()));

                for (int i = 0; i < 4; i++) {
                    output[i] += ".jpg";
                    Log.d("new1", output[i]);
                    //new  GetImage1Async().execute(output[i]);
                }
            } else {
                Log.d("abi1null", null);
            }
        }
    }

    private class GetImage1Async extends AsyncTask<String, Void, Bitmap> {
        @Override
        protected Bitmap doInBackground(String... params) {
            HttpURLConnection connection = null;
            Bitmap bitmap = null;
            URL url = null;
            try {
                url = new URL(params[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.setDoInput(true);
                connection.connect();
                /*for (int i = 0; i < 100; i++) {
                    for (int j = 1; j < 100000; j++) {
                    }
                    publishProgress(i);
                }*/

                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    bitmap = BitmapFactory.decodeStream(connection.getInputStream());
                }

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return bitmap;
        }


        @Override
        protected void onPostExecute(Bitmap bitmap) {
            image.setImageBitmap(bitmap);
        }
    }


}



